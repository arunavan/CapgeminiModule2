# SpringBootMicroservicesDemo

Eureka Server - http://localhost:1111/

Run Consumer Application - http://localhost:8080/
