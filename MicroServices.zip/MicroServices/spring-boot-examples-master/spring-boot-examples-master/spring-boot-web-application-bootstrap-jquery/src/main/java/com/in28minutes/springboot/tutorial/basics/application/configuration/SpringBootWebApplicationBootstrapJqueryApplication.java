package com.in28minutes.springboot.tutorial.basics.application.configuration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebApplicationBootstrapJqueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebApplicationBootstrapJqueryApplication.class, args);
	}
}
