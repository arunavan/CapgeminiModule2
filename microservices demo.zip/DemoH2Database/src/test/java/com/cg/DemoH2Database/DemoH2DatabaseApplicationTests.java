package com.cg.DemoH2Database;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoH2DatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
