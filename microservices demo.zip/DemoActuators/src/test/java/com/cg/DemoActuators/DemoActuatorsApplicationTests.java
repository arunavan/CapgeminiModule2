package com.cg.DemoActuators;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoActuatorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
