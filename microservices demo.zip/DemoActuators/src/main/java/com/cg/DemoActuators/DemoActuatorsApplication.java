package com.cg.DemoActuators;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoActuatorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoActuatorsApplication.class, args);
	}

}
