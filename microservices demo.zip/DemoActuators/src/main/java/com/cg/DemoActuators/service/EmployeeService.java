package com.cg.DemoActuators.service;

import java.util.List;

import com.cg.DemoActuators.dto.Employee;



public interface EmployeeService {
public Employee addEmployee(Employee emp);
public List<Employee> showEmployee();
}

