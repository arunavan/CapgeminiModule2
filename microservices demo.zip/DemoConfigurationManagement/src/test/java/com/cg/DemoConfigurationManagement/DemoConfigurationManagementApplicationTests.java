package com.cg.DemoConfigurationManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoConfigurationManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
