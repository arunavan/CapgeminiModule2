package com.cg.SwaggerBasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwaggerBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
