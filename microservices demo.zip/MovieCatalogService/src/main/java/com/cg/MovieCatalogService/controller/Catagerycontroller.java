package com.cg.MovieCatalogService.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.MovieCatalogService.dto.Movie;



@RestController
@RequestMapping("/cato")
public class Catagerycontroller {
	@RequestMapping("/list")
	public Movie getAllData(){
		return new Movie(1001,"Home Alone...");
		
		
	}
}
